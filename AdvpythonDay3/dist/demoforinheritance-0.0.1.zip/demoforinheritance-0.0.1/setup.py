from distutils.core import setup

setup(
    name='demoforinheritance',
    version='0.0.1',
    packages=['demoforinheritance']
)